import { GoogleGenAI, Type } from "@google/genai";

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

const chatAi = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getGameRecommendation(prompt: string) {
  const response = await chatAi.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: `You are the "AI Game Shopper," a sophisticated game recommendation concierge with a multi-perspective reasoning engine. Your goal is to help players find games based on emotions, taste, and value.
For every user inquiry, you must internally simulate a discussion between three distinct personas:
1. The Hardcore Strategist: Focuses on gameplay mechanics, difficulty curves, depth, and replayability.
2. The Aesthetic Critic: Focuses on art style, soundtrack, narrative atmosphere, and emotional resonance.
3. The Budget Expert: Focuses on price, historical lows, and "bang for your buck."

Output your response in JSON format.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          aesthetic_critic: { type: Type.STRING, description: "A short quote from the Aesthetic Critic." },
          hardcore_strategist: { type: Type.STRING, description: "A short quote from the Hardcore Strategist." },
          budget_expert: { type: Type.STRING, description: "A short quote from the Budget Expert." },
          host_message: { type: Type.STRING, description: "The cohesive, friendly 'concierge-style' message. Include: 1. Empathy Opener. 2. The 'Consultant' Insights (summarizing the 3 experts). 3. Call to Action. Use markdown for formatting." },
          recommended_games: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reason: { type: Type.STRING },
                match_percentage: { type: Type.NUMBER },
                image_keyword: { type: Type.STRING, description: "A single descriptive keyword for the game to fetch a placeholder image from picsum.photos" }
              },
              required: ["title", "reason", "match_percentage", "image_keyword"]
            }
          }
        },
        required: ["aesthetic_critic", "hardcore_strategist", "budget_expert", "host_message", "recommended_games"]
      }
    }
  });

  if (!response.text) throw new Error("No response text");
  return JSON.parse(response.text);
}

export async function generateGameArt(prompt: string, size: "1K" | "2K" | "4K") {
  if (window.aistudio && window.aistudio.hasSelectedApiKey) {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await window.aistudio.openSelectKey();
    }
  }

  // Use process.env.API_KEY if selected by user, otherwise fallback
  const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
  const imageAi = new GoogleGenAI({ apiKey });

  const response = await imageAi.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }],
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
        imageSize: size
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image generated");
}
